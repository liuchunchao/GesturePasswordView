//
//  ViewController.swift
//  GesturePasswordView
//
//  Created by liuchunchao on 2018/1/10.
//  Copyright © 2018年 hi-wallet. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var gestureViewOriginX : CGFloat = kScreenH
    
    //手势密码
    var gesturePsdView : GessturePasswordView? = {
        
        
        let gesturePsdView : GessturePasswordView = GessturePasswordView(frame: CGRect(x: 0, y: 0, width: kScreenW, height: kScreenH))
        gesturePsdView.window?.windowLevel = gesturePasswordViewLevel
        
        return gesturePsdView
    }()
    
    lazy var setButton : UIButton = {
        let setButton = UIButton(frame: CGRect(x: (kScreenW - SP6(x: 150))/2, y: unlockButton.bottom() + SP6(x: 50), width: SP6(x: 150), height: SP6(x: 50)))
        setButton.setTitle("重新设置密码", for: .normal)
        setButton.setTitleColor(UIColor.colorWithHexString(hex: darkBlue), for: .normal)
        setButton.addTarget(self, action: #selector(resetPassword), for: .touchUpInside)
        return setButton
    }()
    
    lazy var unlockButton : UIButton = {
        let unlockButton = UIButton(frame: CGRect(x: (kScreenW - SP6(x: 150))/2, y: SP6(x: 200), width: SP6(x: 150), height: SP6(x: 50)))
        unlockButton.setTitle("输入密码", for: .normal)
        unlockButton.setTitleColor(UIColor.colorWithHexString(hex: darkBlue), for: .normal)
        unlockButton.addTarget(self, action: #selector(settingGesturePassword), for: .touchUpInside)
        return unlockButton
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       view.addSubview(unlockButton)
       view.addSubview(setButton)
       settingGesturePassword()
    }

    
   @objc func settingGesturePassword() {
        
        view.addSubview(gesturePsdView!)
        UIApplication.shared.keyWindow?.addSubview(gesturePsdView!)
        self.gesturePsdView?.frame = CGRect(x: 0, y: gestureViewOriginX, width: kScreenW, height: kScreenH)
        UIView.animate(withDuration: 0.3, animations: {
            self.gesturePsdView?.frame = CGRect(x: 0, y: 0, width: kScreenW, height: kScreenH)
        }) { (finished) in
            
        }
    }
    
    @objc func resetPassword () {
        SettingManager.clearGesturePassword()
        settingGesturePassword()
    }

}

